class Ninja:
    
    def __init__(self, first_name, last_name, pet, pet_food):
        self.first_name = first_name
        self.last_name = last_name
        self.pet = pet
        self.pet_food = pet_food

    def walk(self):
        self.pet.play
        return self

    def feed(self):
        self.pet.eat
        return self

    def bathe(self):
        self.pet.noise
        return self

Kate = Ninja('Kate', 'Barber', ['Sanoma', 'Trinity', 'Alexander'], 'Blue_Wilderness')

Kate.walk().bathe().feed()

# implement the following methods:
# walk() - walks the ninja's pet invoking the pet play() method
# feed() - feeds the ninja's pet invoking the pet eat() method
# bathe() - cleans the ninja's pet invoking the pet noise() method


class Pet:

    def __init__(self, first_name, last_name, species, sound, play, eat):
        self.first_name = first_name
        self.last_name = last_name
        self.species = species
        self.energy = 80
        self.health = 80
        self.sound = sound
        self.play = play
        self.eat = eat

    def sleep(self):
        self.energy += 25
        return self

    def eat(self):
        self.energy += 5
        self.health += 10
        return self

    def play(self):
        self.health += 5
        return self

    def noise(self):
        self.sound()
        return self


# implement the following methods:
# sleep() - increases the pets energy by 25
# eat() - increases the pet's energy by 5 & health by 10
# play() - increases the pet's health by 5
# noise() - prints out the pet's sound

Sanoma = Pet('Sanoma', 'Valley', 'Cat', 'Hiss', 'Just_Nope', 'Blue_Wilderness')
Trinity = Pet('Trinity', 'Valley', 'Cat', 'Meow', 'Climb', 'Blue_Wilderness')
Alexander = Pet('Alexander', 'Valley', 'Cat', 'Purr', 'Fetch', 'Blue_Wilderness')

Sanoma.noise()